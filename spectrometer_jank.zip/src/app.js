import './components/components.index'

let elm = document.createElement('spectrometer-node');

document.body.appendChild(elm);