# In Python 3 command line:

[Python](https://www.python.org/downloads/)

Make sure you have quart (`pip install quart`)



Then run: 
`python server.py`

Then find `http://localhost:7000` to test the websocket

For client.py `pip install websockets` also
